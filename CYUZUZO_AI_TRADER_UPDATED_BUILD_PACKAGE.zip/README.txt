CYUZUZO AI TRADER — Android app project prototype

This ZIP contains Android Studio source code, NOT an APK.
It is a native Android dashboard shell showing the agreed settings:
- MT5 integration planned
- 0.5% risk per trade
- 2% daily loss limit
- Scalping + day-trading strategy selection

The broker connection, secure cloud backend, live market data, strategy engine,
authentication, and order execution are NOT implemented. Trading controls are
intentionally disabled. This prototype cannot place trades.

Build:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Android Gradle Plugin/SDK downloads.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

A signed, tested APK requires building and testing with Android Studio.
Before any real trading, a secure backend and broker-specific MT5 integration
must be developed, audited, and tested on demo. Never embed broker passwords
or API secrets in the Android app.


CLOUD APK BUILD
A GitHub Actions workflow is included at .github/workflows/build-apk.yml.
After uploading this project folder to a GitHub repository:
1. Open the repository's Actions tab.
2. Select "Build CYUZUZO AI TRADER APK".
3. Press "Run workflow".
4. When the run finishes, download the artifact named
   "CYUZUZO-AI-TRADER-debug-apk".

This builds a DEBUG APK for the UI prototype only. It is not a broker-connected
trading app and the trading buttons remain disabled. A debug APK is for testing;
a production release needs a signing key and completed, secured backend.
